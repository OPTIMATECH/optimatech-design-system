// Cole dentro de theme.extend no tailwind.config.js
module.exports = {
  theme: { extend: { colors: { ot: {
    'citrus': '#E6E617',
    'graphite': '#333333',
    'white': '#FFFFFF',
    'ice': '#F1F0F1',
    'mist': '#E3E2E1',
    'gray': '#908F8F',
    'steel': '#808181',
    'iron': '#6B6C6C',
    'carbon': '#262626',
    'lemon': '#EEE454',
    'butter': '#F8D568',
    'sand': '#F1C360',
    'amber': '#FBB03B',
    'bronze': '#A97727',
    'olive': '#B3B336',
    'orange': '#E65717',
    'slate': '#73829D',
    'sol-gemeo': '#2794A8',
    'sol-sensor': '#E65717',
    'sol-coi': '#E6E617',
    'sol-ialab': '#808181',
  } } } }
};
